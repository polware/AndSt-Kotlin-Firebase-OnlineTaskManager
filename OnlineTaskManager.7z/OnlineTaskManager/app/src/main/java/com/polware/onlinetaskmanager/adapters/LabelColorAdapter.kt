package com.polware.onlinetaskmanager.adapters

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.polware.onlinetaskmanager.databinding.ItemLabelColorBinding

class LabelColorAdapter(private val context: Context, private var list: ArrayList<String>,
                        private val selectedColor: String): RecyclerView.Adapter<LabelColorAdapter.MyViewHolder>() {

    var onItemClickListener: OnColorClickListener? = null

    class MyViewHolder(bindingLabelColor: ItemLabelColorBinding):
            RecyclerView.ViewHolder(bindingLabelColor.root) {
        val viewBody = bindingLabelColor.viewMain
        val imageSelectedColor = bindingLabelColor.ivSelectedColor
    }

    interface OnColorClickListener {
        fun onClick(position: Int, color: String)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(ItemLabelColorBinding.inflate(LayoutInflater.from(parent.context),
            parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val itemColor = list[position]
        holder.viewBody.setBackgroundColor(Color.parseColor(itemColor))
        if (itemColor == selectedColor) {
            holder.imageSelectedColor.visibility = View.VISIBLE
        } else {
            holder.imageSelectedColor.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
            if (onItemClickListener != null) {
                onItemClickListener!!.onClick(position, itemColor)
            }
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

}