package com.polware.onlinetaskmanager.activities

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.polware.onlinetaskmanager.R
import com.polware.onlinetaskmanager.databinding.ActivitySignInBinding
import com.polware.onlinetaskmanager.models.User

class SignInActivity : BaseActivity() {
    private lateinit var bindingSignIn: ActivitySignInBinding
    private var auth: FirebaseAuth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingSignIn = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(bindingSignIn.root)
        setupActionBar()

        //auth = FirebaseAuth.getInstance()
        bindingSignIn.buttonLogin.setOnClickListener {
            signInUser()
        }
    }

    fun signInSuccess(user: User){
        hideProgressDialog()
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun setupActionBar(){
        setSupportActionBar(bindingSignIn.toolbarSignIn)
        val actionBar = supportActionBar
        if (actionBar != null){
            actionBar.setDisplayHomeAsUpEnabled(true)
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back_arrow)
            actionBar.title = "Sign In"
        }
        bindingSignIn.toolbarSignIn.setNavigationOnClickListener{
            onBackPressed()
        }
    }

    private fun signInUser() {
        val email = bindingSignIn.editTextEmailLogin.text.toString()
        val password = bindingSignIn.editTextPasswordLogin.text.toString()
        if (validateForm(email, password)){
            showProgressDialog(resources.getString(R.string.please_wait))
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener {
                    task ->
                    hideProgressDialog()
                    if (task.isSuccessful){
                        val user = auth.currentUser

                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    }
                    else {
                        Log.e("signIn failure: ", task.exception!!.message!!)
                        Toast.makeText(this, "Authentication failed", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    private fun validateForm(email: String, password: String): Boolean {
        return when {
            TextUtils.isEmpty(email) -> {
                showErrorMessage("Please enter your Email")
                false
            }
            TextUtils.isEmpty(password) -> {
                showErrorMessage("Please enter your password")
                false
            }
            else -> {
                true
            }
        }
    }

}