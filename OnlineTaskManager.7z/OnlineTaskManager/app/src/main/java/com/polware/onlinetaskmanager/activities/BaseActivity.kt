package com.polware.onlinetaskmanager.activities

import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.polware.onlinetaskmanager.R
import com.polware.onlinetaskmanager.databinding.ActivityBaseBinding

open class BaseActivity : AppCompatActivity() {
    private lateinit var bindingBase: ActivityBaseBinding
    private var doubleBackPressedExit = false
    private lateinit var progressDialog: Dialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingBase = ActivityBaseBinding.inflate(layoutInflater)
        setContentView(bindingBase.root)

    }

    fun getUserID(): String {
        return FirebaseAuth.getInstance().currentUser!!.uid
    }

    fun doubleBackToExit(){
        if(doubleBackPressedExit){
            super.onBackPressed()
            return
        }

        this.doubleBackPressedExit = true
        Toast.makeText(this, resources.getString(R.string.please_click_back_again_to_exit),
            Toast.LENGTH_SHORT).show()
        Handler(Looper.getMainLooper()).postDelayed({
            doubleBackPressedExit = false
        }, 2000)
    }

    fun showProgressDialog(text: String) {
        progressDialog = Dialog(this)
        progressDialog.setContentView(R.layout.custom_progress_dialog)
        val textView = progressDialog.findViewById<TextView>(R.id.tvProgressMessage)
        textView.text = text
        progressDialog.show()
    }

    fun hideProgressDialog() {
        progressDialog.dismiss()
    }

    fun showErrorMessage(message: String) {
        val snackBar = Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG)
        val snackBarView = snackBar.view
        snackBarView.setBackgroundColor(ContextCompat.getColor(this, R.color.snackbar_error_color))
        snackBar.show()
    }

}