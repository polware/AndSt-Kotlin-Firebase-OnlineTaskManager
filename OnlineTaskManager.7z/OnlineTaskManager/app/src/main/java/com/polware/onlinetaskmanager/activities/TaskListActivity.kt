package com.polware.onlinetaskmanager.activities

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import com.polware.onlinetaskmanager.R
import com.polware.onlinetaskmanager.adapters.TaskListAdapter
import com.polware.onlinetaskmanager.databinding.ActivityTaskListBinding
import com.polware.onlinetaskmanager.firebase.FirestoreDB
import com.polware.onlinetaskmanager.models.Board
import com.polware.onlinetaskmanager.models.Card
import com.polware.onlinetaskmanager.models.Task
import com.polware.onlinetaskmanager.models.User
import com.polware.onlinetaskmanager.utils.Constants.BOARD_DETAIL
import com.polware.onlinetaskmanager.utils.Constants.BOARD_MEMBERS_LIST
import com.polware.onlinetaskmanager.utils.Constants.CARD_LIST_ITEM_POSITION
import com.polware.onlinetaskmanager.utils.Constants.DOCUMENT_ID
import com.polware.onlinetaskmanager.utils.Constants.TASK_LIST_ITEM_POSITION

class TaskListActivity : BaseActivity() {
    private lateinit var bindingTaskList: ActivityTaskListBinding
    private lateinit var boardDetails: Board
    private var activityResultLauncherAddingMember: ActivityResultLauncher<Intent>? = null
    private var activityResultLauncherCardDetails: ActivityResultLauncher<Intent>? = null
    private lateinit var boardDocumentId: String
    lateinit var assignedMembersList: ArrayList<User>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingTaskList = ActivityTaskListBinding.inflate(layoutInflater)
        setContentView(bindingTaskList.root)

        if (intent.hasExtra(DOCUMENT_ID)){
            boardDocumentId = intent.getStringExtra(DOCUMENT_ID)!!
        }
        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().getBoardDetails(this, boardDocumentId)
        registerActivityForNewMembers()
        registerActivityForCardDetails()

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_members, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_members -> {
                val intentMembers = Intent(this, MembersActivity::class.java)
                // Clase Board es Parcelable y esto permite pasar objeto completo por Intent
                intentMembers.putExtra(BOARD_DETAIL, boardDetails)
                //startActivity(intentMembers)
                activityResultLauncherAddingMember?.launch(intentMembers)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupActionBar() {
        setSupportActionBar(bindingTaskList.toolbarTaskListActivity)
        val actionBar = supportActionBar
        if (actionBar != null){
            actionBar.setDisplayHomeAsUpEnabled(true)
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back_arrow)
            actionBar.title = boardDetails.name
        }
        bindingTaskList.toolbarTaskListActivity.setNavigationOnClickListener {
            onBackPressed()
        }
    }

    private fun registerActivityForNewMembers() {
        activityResultLauncherAddingMember = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()) { result ->
            val resultCode = result.resultCode
            if (resultCode == RESULT_OK) {
                try {
                    showProgressDialog(resources.getString(R.string.please_wait))
                    FirestoreDB().getBoardDetails(this, boardDocumentId)
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "Error loading new member(s)",
                        Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun boardDetails(board: Board) {
        hideProgressDialog()
        boardDetails = board
        setupActionBar()

        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().getAssignedMembersDetails(this, boardDetails.assignedTo!!)
    }

    fun addUpdateTaskListSuccess() {
        FirestoreDB().getBoardDetails(this, boardDetails.documentId!!)
        hideProgressDialog()
    }

    fun createTaskList(taskListName: String) {
        val task = Task(taskListName, FirestoreDB().getCurrentUserID())
        // Agrega la Tasklist creada en el primer lugar de la vista
        boardDetails.taskList!!.add(0, task)
        boardDetails.taskList!!.removeAt(boardDetails.taskList!!.size - 1)
        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().addUpdateTaskList(this, boardDetails)
    }

    fun updateTaskList(position: Int, listName: String, taskModel: Task) {
        val task = Task(listName, taskModel.createdBy)
        boardDetails.taskList!![position] = task
        boardDetails.taskList!!.removeAt(boardDetails.taskList!!.size - 1)
        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().addUpdateTaskList(this, boardDetails)
    }

    fun deleteTaskList(position: Int) {
        boardDetails.taskList!!.removeAt(position)
        boardDetails.taskList!!.removeAt(boardDetails.taskList!!.size - 1)
        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().addUpdateTaskList(this, boardDetails)
    }

    fun addCardToTaskList(position: Int, cardName: String) {
        boardDetails.taskList!!.removeAt(boardDetails.taskList!!.size - 1)
        val cardAssignedUsersList: ArrayList<String> = ArrayList()
        val createdBy = FirestoreDB().getCurrentUserID()
        cardAssignedUsersList.add(createdBy)
        val newCard = Card(cardName, createdBy, cardAssignedUsersList)
        val cardList = boardDetails.taskList!![position].cards
        cardList!!.add(newCard)
        val task = Task(boardDetails.taskList!![position].title,
            boardDetails.taskList!![position].createdBy, cardList)
        boardDetails.taskList!![position] = task
        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().addUpdateTaskList(this, boardDetails)
    }

    fun cardDetails(taskListPosition: Int, cardPosition: Int) {
        val intentCardDetails = Intent(this, CardDetailsActivity::class.java)
        intentCardDetails.putExtra(BOARD_DETAIL, boardDetails)
        intentCardDetails.putExtra(TASK_LIST_ITEM_POSITION, taskListPosition)
        intentCardDetails.putExtra(CARD_LIST_ITEM_POSITION, cardPosition)
        intentCardDetails.putExtra(BOARD_MEMBERS_LIST, assignedMembersList)
        activityResultLauncherCardDetails?.launch(intentCardDetails)
    }

    private fun registerActivityForCardDetails() {
        activityResultLauncherCardDetails = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()) { result ->
            val resultCode = result.resultCode
            if (resultCode == RESULT_OK) {
                try {
                    showProgressDialog(resources.getString(R.string.please_wait))
                    FirestoreDB().getBoardDetails(this, boardDocumentId)
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "Error loading new member(s)",
                        Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun boardMembersList(membersList: ArrayList<User>) {
        assignedMembersList = membersList
        hideProgressDialog()

        val addTaskList = Task("Add List")
        boardDetails.taskList!!.add(addTaskList)
        bindingTaskList.rvTaskList.layoutManager = LinearLayoutManager(this,
            LinearLayoutManager.HORIZONTAL, false)
        bindingTaskList.rvTaskList.setHasFixedSize(true)
        val adapter = TaskListAdapter(this, boardDetails.taskList!!)
        bindingTaskList.rvTaskList.adapter = adapter
    }

    fun orderCardsInTaskList(taskListPosition: Int, cards: ArrayList<Card>) {
        boardDetails.taskList!!.removeAt(boardDetails.taskList!!.size - 1)
        boardDetails.taskList!![taskListPosition].cards = cards
        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().addUpdateTaskList(this, boardDetails)
    }

}