package com.polware.onlinetaskmanager.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.polware.onlinetaskmanager.R
import com.polware.onlinetaskmanager.databinding.ItemMemberListBinding
import com.polware.onlinetaskmanager.models.User
import com.polware.onlinetaskmanager.utils.Constants

class MemberListAdapter(private val context: Context,
                        private var userList: ArrayList<User>):
    RecyclerView.Adapter<MemberListAdapter.MyViewHolder>() {

    private var onItemClickListener: OnMemberClickListener? = null

    class MyViewHolder(bindingMemberList: ItemMemberListBinding):
            RecyclerView.ViewHolder(bindingMemberList.root) {
        val imageMember = bindingMemberList.ivMemberImage
        val textViewMemberName = bindingMemberList.tvMemberName
        val textViewMemberEmail = bindingMemberList.tvMemberEmail
        val imageSelectedItem = bindingMemberList.ivSelectedMember
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(ItemMemberListBinding
            .inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val userModel = userList[position]
        Glide.with(context).load(userModel.image)
                .centerCrop().placeholder(R.drawable.ic_user_place_holder)
                .into(holder.imageMember)
        holder.textViewMemberName.text = userModel.name
        holder.textViewMemberEmail.text = userModel.email

        if (userModel.selected) {
            holder.imageSelectedItem.visibility = View.VISIBLE
        }
        else {
            holder.imageSelectedItem.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
        if (onItemClickListener != null) {
            if (userModel.selected) {
                onItemClickListener!!.onClick(position, userModel, Constants.UNSELECT)
            }
            else {
                onItemClickListener!!.onClick(position, userModel, Constants.SELECT)
                }
            }
        }

    }

    override fun getItemCount(): Int {
        return userList.size
    }

    fun setOnClickListener(onClickListener: OnMemberClickListener) {
        this.onItemClickListener = onClickListener
    }

    interface OnMemberClickListener {
        fun onClick(position: Int, user: User, action: String)
    }

}