package com.polware.onlinetaskmanager.activities

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.polware.onlinetaskmanager.R
import com.polware.onlinetaskmanager.adapters.MemberListAdapter
import com.polware.onlinetaskmanager.databinding.ActivityMembersBinding
import com.polware.onlinetaskmanager.firebase.FirestoreDB
import com.polware.onlinetaskmanager.models.Board
import com.polware.onlinetaskmanager.models.User
import com.polware.onlinetaskmanager.utils.Constants.BOARD_DETAIL
import com.polware.onlinetaskmanager.utils.Constants.FCM_AUTHORIZATION
import com.polware.onlinetaskmanager.utils.Constants.FCM_BASE_URL
import com.polware.onlinetaskmanager.utils.Constants.FCM_KEY
import com.polware.onlinetaskmanager.utils.Constants.FCM_KEY_DATA
import com.polware.onlinetaskmanager.utils.Constants.FCM_KEY_MESSAGE
import com.polware.onlinetaskmanager.utils.Constants.FCM_KEY_TITLE
import com.polware.onlinetaskmanager.utils.Constants.FCM_KEY_TO
import com.polware.onlinetaskmanager.utils.Constants.FCM_SERVER_KEY
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

class MembersActivity : BaseActivity() {
    private lateinit var bindingMembers: ActivityMembersBinding
    private lateinit var boardDetails: Board
    private lateinit var assignedMembersList: ArrayList<User>
    private var observeChanges: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingMembers = ActivityMembersBinding.inflate(layoutInflater)
        setContentView(bindingMembers.root)
        setupActionBar()

        if (intent.hasExtra(BOARD_DETAIL)) {
            boardDetails = intent.getParcelableExtra(BOARD_DETAIL)!!
            showProgressDialog(resources.getString(R.string.please_wait))
            FirestoreDB().getAssignedMembersDetails(this, boardDetails.assignedTo!!)
        }

    }

    private fun setupActionBar() {
        setSupportActionBar(bindingMembers.toolbarMembersActivity)
        val actionBar = supportActionBar
        if (actionBar != null){
            actionBar.setDisplayHomeAsUpEnabled(true)
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back_arrow)
            actionBar.title = "Members"
        }
        bindingMembers.toolbarMembersActivity.setNavigationOnClickListener {
            onBackPressed()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add_member, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_add_member -> {
                dialogSearchMember()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun dialogSearchMember() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_search_member)
        val editTextEmail = dialog.findViewById<EditText>(R.id.et_email_search_member)
        val buttonAdd = dialog.findViewById<TextView>(R.id.tv_add)
        val buttonCancel = dialog.findViewById<TextView>(R.id.tv_cancel)
        buttonAdd.setOnClickListener {
            val email = editTextEmail.text.toString()
            if (email.isNotEmpty()) {
                showProgressDialog(resources.getString(R.string.please_wait))
                FirestoreDB().getMemberDetails(this, email)
                dialog.dismiss()
            }
            else {
                Toast.makeText(this, "Please enter a member email address", Toast.LENGTH_SHORT).show()
            }
        }
        buttonCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

    fun setupMembersList(memberList: ArrayList<User>) {
        hideProgressDialog()
        assignedMembersList = memberList
        bindingMembers.rvMembersList.layoutManager = LinearLayoutManager(this)
        bindingMembers.rvMembersList.setHasFixedSize(true)
        val adapter = MemberListAdapter(this, memberList)
        bindingMembers.rvMembersList.adapter = adapter
    }

    fun memberDetails(user: User) {
        boardDetails.assignedTo!!.add(user.id!!)
        FirestoreDB().assignMemberToBoard(this, boardDetails, user)
    }

    fun memberAssignedSuccess(user: User) {
        hideProgressDialog()
        assignedMembersList.add(user)
        observeChanges = true
        // Agrega en pantalla al usuario encontrado
        setupMembersList(assignedMembersList)
        SendNotificationAsyncTask(boardDetails.name!!, user.userToken!!).execute()
    }

    override fun onBackPressed() {
        if (observeChanges) {
            setResult(Activity.RESULT_OK)
        }
        super.onBackPressed()
    }

    @SuppressLint("StaticFieldLeak")
    private inner class SendNotificationAsyncTask(val boardName: String,
                                                  val token: String): AsyncTask<Any, Void, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
            showProgressDialog(resources.getString(R.string.please_wait))
        }

        override fun doInBackground(vararg p0: Any?): String {
            var result: String = ""
            var connection: HttpURLConnection? = null
            try {
                val url = URL(FCM_BASE_URL)
                connection = url.openConnection() as HttpURLConnection
                connection.doOutput = true
                connection.doInput = true
                connection.instanceFollowRedirects = false
                connection.requestMethod = "POST"
                // Sets the general request property
                connection.setRequestProperty("Content-Type", "application/json")
                connection.setRequestProperty("charset", "utf-8")
                connection.setRequestProperty("Accept", "application/json")
                connection.setRequestProperty(FCM_AUTHORIZATION, "${FCM_KEY}=${FCM_SERVER_KEY}")
                connection.useCaches = false
                // Creates a new data output stream to write data to the specified underlying output stream
                val wr = DataOutputStream(connection.outputStream)
                // Create JSONObject Request
                val jsonRequest = JSONObject()
                val dataObject = JSONObject()
                dataObject.put(FCM_KEY_TITLE, "Assigned to the Board $boardName")
                dataObject.put(FCM_KEY_MESSAGE, "You have been assigned to the new board by ${assignedMembersList[0].name}")
                // Here add the data object and user's token in the jsonRequest
                jsonRequest.put(FCM_KEY_DATA, dataObject)
                jsonRequest.put(FCM_KEY_TO, token)
                // Writes out the string to the underlying output stream as a sequence of bytes
                wr.writeBytes(jsonRequest.toString())
                wr.flush()
                wr.close()
                // Gets the status code from an HTTP response message
                val httpResult = connection.responseCode
                if (httpResult == HttpURLConnection.HTTP_OK) {
                    // Returns an input stream that reads from this open connection
                    val inputStream = connection.inputStream
                    val reader = BufferedReader(InputStreamReader(inputStream))
                    val sb = StringBuilder()
                    var line: String?
                    try {
                        while (reader.readLine().also { line = it } != null) {
                            sb.append(line + "\n")
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    } finally {
                        try {
                            inputStream.close()
                        } catch (e: IOException) {
                            e.printStackTrace()
                        }
                    }
                    result = sb.toString()
                }
                else {
                    // Gets the HTTP response message
                    result = connection.responseMessage
                }
            }
            catch (e: SocketTimeoutException) {
                Log.e("SocketException:", e.message.toString())
                result = "Connection Timeout"
            }
            catch (e: Exception) {
                Log.e("ErrorSendNotification:", e.message.toString())
            }
            finally {
                connection!!.disconnect()
            }
            return result
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            hideProgressDialog()
            Log.i("JSON response: ", result!!)
        }

    }

}