package com.polware.onlinetaskmanager.activities

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.polware.onlinetaskmanager.R
import com.polware.onlinetaskmanager.adapters.CardMembersListAdapter
import com.polware.onlinetaskmanager.databinding.ActivityCardDetailsBinding
import com.polware.onlinetaskmanager.dialogs.LabelColorDialog
import com.polware.onlinetaskmanager.dialogs.MembersListDialog
import com.polware.onlinetaskmanager.firebase.FirestoreDB
import com.polware.onlinetaskmanager.models.*
import com.polware.onlinetaskmanager.utils.Constants.BOARD_DETAIL
import com.polware.onlinetaskmanager.utils.Constants.BOARD_MEMBERS_LIST
import com.polware.onlinetaskmanager.utils.Constants.CARD_LIST_ITEM_POSITION
import com.polware.onlinetaskmanager.utils.Constants.SELECT
import com.polware.onlinetaskmanager.utils.Constants.TASK_LIST_ITEM_POSITION
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class CardDetailsActivity : BaseActivity() {
    private lateinit var bindingCardDetails: ActivityCardDetailsBinding
    private lateinit var boardDetails: Board
    private lateinit var cardName: String
    private var taskListPosition = -1
    private var cardPosition = -1
    private var labelColor = ""
    private lateinit var assignedMembersList: ArrayList<User>
    private var dateInMilliseconds: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingCardDetails = ActivityCardDetailsBinding.inflate(layoutInflater)
        setContentView(bindingCardDetails.root)
        getIntentData()
        setupActionBar()
        cardName = boardDetails.taskList!![taskListPosition].cards!![cardPosition].name!!
        bindingCardDetails.etNameCardDetails.setText(cardName)
        // Set focus at the end of text
        bindingCardDetails.etNameCardDetails.setSelection(bindingCardDetails.etNameCardDetails.text.toString().length)

        labelColor = boardDetails.taskList!![taskListPosition].cards!![cardPosition].labelColor!!
        if (labelColor.isNotEmpty())
            setColor()

        bindingCardDetails.btnUpdateCardDetails.setOnClickListener {
            if (bindingCardDetails.etNameCardDetails.text.toString().isNotEmpty())
                updateCardDetails()
            else
                Toast.makeText(this, "Please enter a Card name", Toast.LENGTH_SHORT).show()
        }
        setupSelectedMembersList()

        bindingCardDetails.tvSelectLabelColor.setOnClickListener {
            dialogSelectLabelColor()
        }

        bindingCardDetails.tvSelectMembers.setOnClickListener {
            dialogMembersList()
        }

        dateInMilliseconds = boardDetails.taskList!![taskListPosition].cards!![cardPosition].dueDate
        if (dateInMilliseconds > 0) {
            val simpleDateFormat = SimpleDateFormat("dd/MM/yy", Locale.ENGLISH)
            val selectedDate = simpleDateFormat.format(Date(dateInMilliseconds))
            bindingCardDetails.tvSelectDueDate.text = selectedDate
        }

        bindingCardDetails.tvSelectDueDate.setOnClickListener {
            showDatePicker()
        }

    }

    private fun setupActionBar() {
        setSupportActionBar(bindingCardDetails.toolbarCardDetailsActivity)
        val actionBar = supportActionBar
        if (actionBar != null){
            actionBar.setDisplayHomeAsUpEnabled(true)
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back_arrow)
            actionBar.title = boardDetails.taskList!![taskListPosition].cards!![cardPosition].name
        }
        bindingCardDetails.toolbarCardDetailsActivity.setNavigationOnClickListener {
            onBackPressed()
        }
    }

    private fun getIntentData() {
        if (intent.hasExtra(BOARD_DETAIL)) {
            boardDetails = intent.getParcelableExtra(BOARD_DETAIL)!!
        }
        if (intent.hasExtra(TASK_LIST_ITEM_POSITION)) {
            taskListPosition = intent.getIntExtra(TASK_LIST_ITEM_POSITION, -1)
        }
        if (intent.hasExtra(CARD_LIST_ITEM_POSITION)) {
            cardPosition = intent.getIntExtra(CARD_LIST_ITEM_POSITION, -1)
        }
        if (intent.hasExtra(BOARD_MEMBERS_LIST)) {
            assignedMembersList = intent.getParcelableArrayListExtra(BOARD_MEMBERS_LIST)!!
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_delete_card, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_delete_card -> {
                alertDialogDeleteCard(cardName)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun updateCardDetails() {
        val name = bindingCardDetails.etNameCardDetails.text.toString()
        val createdBy = boardDetails.taskList!![taskListPosition].cards!![cardPosition].createdBy
        val assignedTo = boardDetails.taskList!![taskListPosition].cards!![cardPosition].assignedTo
        val card = Card(name, createdBy, assignedTo, labelColor, dateInMilliseconds)
        // Update the Task List on UI
        val taskList: ArrayList<Task> = boardDetails.taskList!!
        taskList.removeAt(taskList.size - 1)

        boardDetails.taskList!![taskListPosition].cards!![cardPosition] = card
        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().addUpdateTaskList(this, boardDetails)
    }

    private fun deleteCard() {
        val cardsList: ArrayList<Card> = boardDetails.taskList!![taskListPosition].cards!!
        cardsList.removeAt(cardPosition)
        val taskList: ArrayList<Task> = boardDetails.taskList!!
        taskList.removeAt(taskList.size - 1)
        taskList!![taskListPosition].cards = cardsList
        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().addUpdateTaskList(this, boardDetails)
    }

    private fun alertDialogDeleteCard(cardName: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Delete Card")
        builder.setMessage(resources.getString(R.string.confirmation_message_to_delete_card, cardName))
        builder.setIcon(android.R.drawable.ic_dialog_alert)
        builder.setPositiveButton("Yes") { dialogInterface, _ ->
            dialogInterface.dismiss()
            deleteCard()
        }
        builder.setNegativeButton("No") { dialogInterface, _ ->
            dialogInterface.dismiss()
        }

        val alertDialog: AlertDialog = builder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun dialogSelectLabelColor() {
        val colorsList: ArrayList<String> = colorsList()
        val colorListDialog = object : LabelColorDialog(this,
                            colorsList, "Select Label Color", labelColor) {
            override fun onColorSelected(color: String) {
                labelColor = color
                setColor()
            }
        }
        colorListDialog.show()
    }

    private fun setColor() {
        bindingCardDetails.tvSelectLabelColor.text = ""
        bindingCardDetails.tvSelectLabelColor.setBackgroundColor(Color.parseColor(labelColor))
    }

    private fun colorsList(): ArrayList<String> {
        val arrayColorList: ArrayList<String> = ArrayList()
        arrayColorList.add("#43C86F")
        arrayColorList.add("#0C90F1")
        arrayColorList.add("#F72400")
        arrayColorList.add("#7A8089")
        arrayColorList.add("#D57C1D")
        arrayColorList.add("#770000")
        arrayColorList.add("#0022F8")
        return arrayColorList
    }

    private fun dialogMembersList() {
        val cardAssignedMembers = boardDetails.taskList!![taskListPosition].cards!![cardPosition].assignedTo
        if (cardAssignedMembers!!.size > 0) {
            for (i in assignedMembersList.indices) {
                for (j in cardAssignedMembers) {
                    if (assignedMembersList[i].id == j) {
                        assignedMembersList[i].selected = true
                    }
                }
            }
        }
        else {
            for (i in assignedMembersList.indices) {
                assignedMembersList[i].selected = false
            }
        }

        val membersListDialog = object : MembersListDialog(this, assignedMembersList, "Select Member") {
            override fun onMemberSelected(user: User, action: String) {
                if (action == SELECT) {
                    if (!boardDetails.taskList!![taskListPosition].cards!![cardPosition].assignedTo!!.contains(user.id!!)) {
                        boardDetails.taskList!![taskListPosition].cards!![cardPosition].assignedTo!!.add(user.id)
                    }
                }
                else {
                    boardDetails.taskList!![taskListPosition].cards!![cardPosition].assignedTo!!.remove(user.id)
                    for (i in assignedMembersList.indices) {
                        if (assignedMembersList[i].id == user.id) {
                            assignedMembersList[i].selected = false
                        }
                    }
                }
                setupSelectedMembersList()
            }
        }
        membersListDialog.show()
    }

    private fun setupSelectedMembersList() {
        val cardAssignedMembersList = boardDetails.taskList!![taskListPosition].cards!![cardPosition].assignedTo
        val selectedMembersList: ArrayList<SelectedMembers> = ArrayList()
        for (i in assignedMembersList.indices) {
            for (j in cardAssignedMembersList!!) {
                if (assignedMembersList[i].id == j) {
                    val selectedMember = SelectedMembers(assignedMembersList[i].id,
                        assignedMembersList[i].image)
                    selectedMembersList.add(selectedMember)
                }
            }
        }
        if (selectedMembersList.size > 0) {
            selectedMembersList.add(SelectedMembers("",""))
            bindingCardDetails.tvSelectMembers.visibility = View.GONE
            bindingCardDetails.rvSelectedMembersList.visibility = View.VISIBLE

            bindingCardDetails.rvSelectedMembersList.layoutManager = GridLayoutManager(this, 6)
            // Se asigna True a assignMembers para habilitar opción de agregar
            val adapter = CardMembersListAdapter(this, selectedMembersList, true)
            bindingCardDetails.rvSelectedMembersList.adapter = adapter

            adapter.setOnClickListener(object : CardMembersListAdapter.OnItemClickListener {
                override fun onClick() {
                    dialogMembersList()
                }
            })
        }
        else {
            bindingCardDetails.tvSelectMembers.visibility = View.VISIBLE
            bindingCardDetails.rvSelectedMembersList.visibility = View.GONE
        }
    }

    private fun showDatePicker() {
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        val dateDialog = DatePickerDialog(this, {
                _, yearPicked, monthOfYear, dayOfMonth ->
                // Here we have appended 0 if the selected day is smaller than 10 to make it double digit value.
                val sDayOfMonth = if (dayOfMonth < 10) "0$dayOfMonth" else "$dayOfMonth"
                // Here we have appended 0 if the selected month is smaller than 10 to make it double digit value.
                val sMonthOfYear = if ((monthOfYear + 1) < 10) "0${monthOfYear + 1}" else "${monthOfYear + 1}"

                val selectedDate = "$sDayOfMonth/$sMonthOfYear/$yearPicked"
                bindingCardDetails.tvSelectDueDate.text = selectedDate
                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)

                // The formatter will parse the selected date in to Date object
                val theDate = sdf.parse(selectedDate)
                dateInMilliseconds = theDate!!.time
            },
            year,
            month,
            day
        )
        dateDialog.show()
    }

    fun addUpdateCardListSuccess() {
        hideProgressDialog()
        setResult(Activity.RESULT_OK)
        finish()
    }

}