package com.polware.onlinetaskmanager.activities

import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.polware.onlinetaskmanager.R
import com.polware.onlinetaskmanager.databinding.ActivitySignUpBinding
import com.polware.onlinetaskmanager.firebase.FirestoreDB
import com.polware.onlinetaskmanager.models.User

class SignUpActivity : BaseActivity() {
    private lateinit var bindingRegister: ActivitySignUpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingRegister = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(bindingRegister.root)
        setupActionBar()

        bindingRegister.buttonRegister.setOnClickListener {
            registerUser()
        }

    }

    private fun setupActionBar(){
        setSupportActionBar(bindingRegister.toolbarSignUp)
        val actionBar = supportActionBar
        if (actionBar != null){
            actionBar.setDisplayHomeAsUpEnabled(true)
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back_arrow)
            actionBar.title = "Sign Up"
        }
        bindingRegister.toolbarSignUp.setNavigationOnClickListener{
            onBackPressed()
        }
    }

    private fun registerUser() {
        val name: String = bindingRegister.editTextName.text.toString().trim() { it <= ' ' } // Trim borra espacios del final
        val email: String = bindingRegister.editTextEmail.text.toString().trim() { it <= ' ' }
        val password: String = bindingRegister.editTextPassword.text.toString()
        if (validateForm(name, email, password)) {
            showProgressDialog(resources.getString(R.string.please_wait))
            FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener {
                    task ->
                    hideProgressDialog()
                    if (task.isSuccessful){
                        val firebaseUser: FirebaseUser = task.result.user!!
                        val registeredEmail = firebaseUser.email
                        val user = User(firebaseUser.uid, name, registeredEmail)
                        FirestoreDB().registerUserToDB(this, user)
                    }
                    else {
                        Log.e("signIn failure: ", task.exception!!.message!!)
                        Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    private fun validateForm(name: String, email: String, password: String): Boolean {
        return when {
            TextUtils.isEmpty(name) -> {
                showErrorMessage("Please enter your name")
                false
            }
            TextUtils.isEmpty(email) -> {
                showErrorMessage("Please enter your Email")
                false
            }
            TextUtils.isEmpty(password) -> {
                showErrorMessage("Please enter your password")
                false
            }
            else -> {
                true
            }
        }
    }

    fun registeredUserConfirmation(){
        Toast.makeText(this, "Successfully registered user", Toast.LENGTH_SHORT).show()
        FirebaseAuth.getInstance().signOut()
        finish()
    }

}