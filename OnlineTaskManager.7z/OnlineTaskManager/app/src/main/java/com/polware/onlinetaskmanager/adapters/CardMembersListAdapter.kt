package com.polware.onlinetaskmanager.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.polware.onlinetaskmanager.R
import com.polware.onlinetaskmanager.databinding.CardSelectedMemberBinding
import com.polware.onlinetaskmanager.models.SelectedMembers

open class CardMembersListAdapter(private val context: Context,
                                  private val membersList: ArrayList<SelectedMembers>,
                                  private val assignMembers: Boolean):
            RecyclerView.Adapter<CardMembersListAdapter.MyViewHolder>() {

    private var onItemClickListener: OnItemClickListener? = null

    class MyViewHolder(bindingCardMembers: CardSelectedMemberBinding):
                RecyclerView.ViewHolder(bindingCardMembers.root) {
        val imageAddMember = bindingCardMembers.ivAddMember
        val imageMemberSelected = bindingCardMembers.ivSelectedMemberImage
    }

    fun setOnClickListener(onItemClickListener: OnItemClickListener) {
        this.onItemClickListener = onItemClickListener
    }

    interface OnItemClickListener {
        fun onClick()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(CardSelectedMemberBinding.inflate(LayoutInflater
            .from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val model = membersList[position]

        if (position == membersList.size - 1 && assignMembers) {
            holder.imageAddMember.visibility = View.VISIBLE
            holder.imageMemberSelected.visibility = View.GONE
            }
        else {
            holder.imageAddMember.visibility = View.GONE
            holder.imageMemberSelected.visibility = View.VISIBLE
            Glide.with(context).load(model.image)
                    .centerCrop()
                    .placeholder(R.drawable.ic_user_place_holder)
                    .into(holder.imageMemberSelected)
            }

        holder.itemView.setOnClickListener {
            if (onItemClickListener != null) {
                onItemClickListener!!.onClick()
            }
        }
    }

    override fun getItemCount(): Int {
        return membersList.size
    }

}