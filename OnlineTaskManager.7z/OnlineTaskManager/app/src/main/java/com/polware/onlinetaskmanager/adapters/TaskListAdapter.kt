package com.polware.onlinetaskmanager.adapters

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.res.Resources
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.polware.onlinetaskmanager.activities.TaskListActivity
import com.polware.onlinetaskmanager.databinding.ItemTaskBinding
import com.polware.onlinetaskmanager.models.Task
import java.util.*
import kotlin.collections.ArrayList

open class TaskListAdapter(private val context: Context, private var taskList: ArrayList<Task>):
    RecyclerView.Adapter<TaskListAdapter.MyViewHolder>() {

    private var positionDraggedFrom = -1
    private var positionDraggedTo = -1

    class MyViewHolder(bindingTask: ItemTaskBinding): RecyclerView.ViewHolder(bindingTask.root) {
        // Sección Task List
        val textViewAddTasklist = bindingTask.tvAddTaskList
        val linearLayoutTaskItem = bindingTask.llTaskItem
        val textViewTasklistTitle = bindingTask.tvTaskListTitle
        val cardViewAddTasklist = bindingTask.cvAddTaskListName
        val imageCancelListName = bindingTask.ibCancelListName
        val imageSaveListName = bindingTask.ibSaveListName
        val editTextTaskListName = bindingTask.etTaskListName
        val imageEditTaskListName = bindingTask.ibEditTasklistName
        val linearLayoutTitleTask = bindingTask.llTitleView
        val cardViewEditTaskListName = bindingTask.cvEditTaskListName
        val imageCancelEditTaskListName = bindingTask.ibCloseEditableView
        val imageSaveEditTaskListName = bindingTask.ibSaveEditListName
        val editTextEditTaskListName = bindingTask.etEditTaskListName
        val imageDeleteTaskList = bindingTask.ibDeleteTasklist
        // Sección Cards
        val textViewAddCard = bindingTask.tvAddCard
        val cardViewAddCard = bindingTask.cvAddCard
        val imageCancelAddCard = bindingTask.ibCancelAddCard
        val imageSaveNewCard = bindingTask.ibSaveCardName
        val editTextCardName = bindingTask.etCardName
        val recyclerViewCardList = bindingTask.rvCardList
    }

    // Calculate screen density pixel
    private fun Int.toDP(): Int = (this / Resources.getSystem().displayMetrics.density).toInt()

    // Calculate pixels from density
    private fun Int.toPX(): Int = (this * Resources.getSystem().displayMetrics.density).toInt()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val viewBinding = ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        // Define to use 70% width screen for View
        val layoutParams = LinearLayout.LayoutParams((parent.width *0.7).toInt(),
            LinearLayout.LayoutParams.WRAP_CONTENT)
        // Define left margin to 15dp and right margin to 40dp
        layoutParams.setMargins((15.toDP().toPX()), 0, (40.toDP().toPX()), 0)
        viewBinding.root.layoutParams = layoutParams
        return MyViewHolder(viewBinding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, @SuppressLint("RecyclerView") position: Int) {
        val taskModel = taskList[position]
        if (position == taskList.size - 1){
            holder.textViewAddTasklist.visibility = View.VISIBLE
            holder.linearLayoutTaskItem.visibility = View.GONE
        }
        else {
            holder.textViewAddTasklist.visibility = View.GONE
            holder.linearLayoutTaskItem.visibility = View.VISIBLE
        }
        holder.textViewTasklistTitle.text = taskModel.title
        // Botón que activa creación de nueva Task list
        holder.textViewAddTasklist.setOnClickListener {
            holder.textViewAddTasklist.visibility = View.GONE
            holder.cardViewAddTasklist.visibility = View.VISIBLE
        }
        // Cancela creación de nueva Task list
        holder.imageCancelListName.setOnClickListener {
            holder.textViewAddTasklist.visibility = View.VISIBLE
            holder.cardViewAddTasklist.visibility = View.GONE
        }
        // Botón que crea nueva Task list
        holder.imageSaveListName.setOnClickListener {
            val taskListName = holder.editTextTaskListName.text.toString()
            if (taskListName.isNotEmpty()) {
                if (context is TaskListActivity){
                    context.createTaskList(taskListName)
                }
            }
            else {
                Toast.makeText(context, "Please enter a task list name", Toast.LENGTH_SHORT).show()
            }
        }
        // Botón que edita nombre de la Task list
        holder.imageEditTaskListName.setOnClickListener {
            holder.editTextEditTaskListName.setText(taskModel.title)
            holder.linearLayoutTitleTask.visibility = View.GONE
            holder.cardViewEditTaskListName.visibility = View.VISIBLE
        }
        // Cancela edición de Task list
        holder.imageCancelEditTaskListName.setOnClickListener {
            holder.linearLayoutTitleTask.visibility = View.VISIBLE
            holder.cardViewEditTaskListName.visibility = View.GONE
        }
        // Guarda el nuevo nombre de la Task list
        holder.imageSaveEditTaskListName.setOnClickListener {
            val listName = holder.editTextEditTaskListName.text.toString()
            if (listName.isNotEmpty()) {
                if (context is TaskListActivity){
                    context.updateTaskList(position, listName, taskModel)
                }
            }
            else {
                Toast.makeText(context, "Please enter the new TaskList name", Toast.LENGTH_SHORT).show()
            }
        }
        // Elimina la Task list selecionada
        holder.imageDeleteTaskList.setOnClickListener {
            alertDialogForDeleteList(position, taskModel.title)
        }

        // Botón crear nueva Card
        holder.textViewAddCard.setOnClickListener {
            holder.textViewAddCard.visibility = View.GONE
            holder.cardViewAddCard.visibility = View.VISIBLE
        }

        // Imagen cancelar nueva Card
        holder.imageCancelAddCard.setOnClickListener {
            holder.textViewAddCard.visibility = View.VISIBLE
            holder.cardViewAddCard.visibility = View.GONE
        }

        // Imagen crear nueva Card
        holder.imageSaveNewCard.setOnClickListener {
            val cardName = holder.editTextCardName.text.toString()
            if (cardName.isNotEmpty()) {
                if (context is TaskListActivity){
                    context.addCardToTaskList(position, cardName)
                }
            }
            else {
                Toast.makeText(context, "Please enter a Card name", Toast.LENGTH_SHORT).show()
            }
        }
        // Declaramos adapter adicional para el RecyclerView de Card List
        holder.recyclerViewCardList.layoutManager = LinearLayoutManager(context)
        holder.recyclerViewCardList.setHasFixedSize(true)
        val adapterCardList = CardListAdapter(context, taskModel.cards!!)
        holder.recyclerViewCardList.adapter = adapterCardList
        adapterCardList.setOnItemClickListener(object : CardListAdapter.OnCardItemClickListener {
            override fun onClick(cardPosition: Int) {
                if (context is TaskListActivity) {
                    context.cardDetails(position, cardPosition)
                }
            }
        })

        // Implementamos arrastrar y soltar items dentro de la Card
        val dividerItemDecoration = DividerItemDecoration(context, DividerItemDecoration.VERTICAL)
        holder.recyclerViewCardList.addItemDecoration(dividerItemDecoration)
        val touchHelper = ItemTouchHelper(object:
                ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {

            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder): Boolean {
                val draggedPosition = viewHolder.adapterPosition
                val targetPosition = target.adapterPosition
                if (positionDraggedFrom == -1)
                    positionDraggedFrom = draggedPosition
                positionDraggedTo = targetPosition
                // Swaps elements at the specified positions in the specified list
                Collections.swap(taskList[position].cards, draggedPosition, targetPosition)
                adapterCardList.notifyItemMoved(draggedPosition, targetPosition)
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                TODO("Not yet implemented")
            }

            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                if (positionDraggedFrom != -1 && positionDraggedTo != -1
                    && positionDraggedFrom != positionDraggedTo) {
                    (context as TaskListActivity).orderCardsInTaskList(position, taskList[position].cards!!)
                }
                positionDraggedFrom = -1
                positionDraggedTo = -1
            }
        })
        touchHelper.attachToRecyclerView(holder.recyclerViewCardList)

    }

    override fun getItemCount(): Int {
        return taskList.size
    }

    private fun alertDialogForDeleteList(position: Int, title: String?) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Alert")
        builder.setMessage("Are you sure you want to delete $title.")
        builder.setIcon(android.R.drawable.ic_dialog_alert)

        builder.setPositiveButton("Yes") { dialogInterface, which ->
            dialogInterface.dismiss()
            if (context is TaskListActivity) {
                context.deleteTaskList(position)
            }
        }

        builder.setNegativeButton("No") { dialogInterface, which ->
            dialogInterface.dismiss() // Dialog will be dismissed
        }

        val alertDialog: AlertDialog = builder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

}