package com.polware.onlinetaskmanager.activities

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.polware.onlinetaskmanager.databinding.ActivitySplashBinding
import com.polware.onlinetaskmanager.firebase.FirestoreDB

class SplashActivity : AppCompatActivity() {
    private lateinit var bindingSplash: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingSplash = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(bindingSplash.root)

        val typeFace: Typeface = Typeface.createFromAsset(assets, "saucerbb_font.ttf")
        bindingSplash.textViewAppName.typeface = typeFace

        Handler(Looper.getMainLooper()).postDelayed({
            // Obtenemos UID del usuario para loguearlo automáticamente
            val currentUserID = FirestoreDB().getCurrentUserID()
            if (currentUserID.isNotEmpty()){
                startActivity(Intent(this, MainActivity::class.java))
            }
            else {
                startActivity(Intent(this, IntroActivity::class.java))
            }
            finish()
        }, 2500)

    }
}