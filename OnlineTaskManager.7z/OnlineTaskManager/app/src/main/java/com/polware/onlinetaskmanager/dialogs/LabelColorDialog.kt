package com.polware.onlinetaskmanager.dialogs

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.polware.onlinetaskmanager.adapters.LabelColorAdapter
import com.polware.onlinetaskmanager.databinding.DialogColorListBinding

abstract class LabelColorDialog(context: Context, private var colorList: ArrayList<String>,
                                private val title: String = "",
                                private var selectedColor: String = ""): Dialog(context) {

    private lateinit var bindingLabelDialog: DialogColorListBinding
    private var adapter: LabelColorAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindingLabelDialog = DialogColorListBinding.inflate(layoutInflater)
        setContentView(bindingLabelDialog.root)
        setCanceledOnTouchOutside(true)
        setCancelable(true)
        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        bindingLabelDialog.tvTitle.text = title
        bindingLabelDialog.rvList.layoutManager = LinearLayoutManager(context)
        adapter = LabelColorAdapter(context, colorList, selectedColor)
        bindingLabelDialog.rvList.adapter = adapter
        adapter!!.onItemClickListener = object : LabelColorAdapter.OnColorClickListener {
            override fun onClick(position: Int, color: String) {
                dismiss()
                onColorSelected(color)
            }
        }
    }

    protected abstract fun onColorSelected(color: String)

}