package com.polware.onlinetaskmanager.dialogs

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.polware.onlinetaskmanager.adapters.MemberListAdapter
import com.polware.onlinetaskmanager.databinding.DialogMemberListBinding
import com.polware.onlinetaskmanager.models.User

abstract class MembersListDialog(context: Context, private var list: ArrayList<User>,
                                 private val title: String = "") : Dialog(context) {

    private lateinit var bindingMembersDialog: DialogMemberListBinding
    private var adapter: MemberListAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState ?: Bundle())
        bindingMembersDialog = DialogMemberListBinding.inflate(layoutInflater)
        setContentView(bindingMembersDialog.root)
        setCanceledOnTouchOutside(true)
        setCancelable(true)
        setUpRecyclerView()
    }

    private fun setUpRecyclerView() {
        bindingMembersDialog.tvTitle.text = title
        if (list.size > 0) {
            bindingMembersDialog.rvMemberList.layoutManager = LinearLayoutManager(context)
            adapter = MemberListAdapter(context, list)
            bindingMembersDialog.rvMemberList.adapter = adapter

            adapter!!.setOnClickListener(object :
                MemberListAdapter.OnMemberClickListener {
                override fun onClick(position: Int, user: User, action:String) {
                    dismiss()
                    onMemberSelected(user, action)
                }
            })
        }
    }

    protected abstract fun onMemberSelected(user: User, action:String)

}