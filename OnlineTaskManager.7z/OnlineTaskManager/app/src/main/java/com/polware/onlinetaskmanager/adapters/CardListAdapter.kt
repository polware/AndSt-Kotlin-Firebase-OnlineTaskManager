package com.polware.onlinetaskmanager.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.polware.onlinetaskmanager.activities.TaskListActivity
import com.polware.onlinetaskmanager.databinding.ItemCardBinding
import com.polware.onlinetaskmanager.models.Card
import com.polware.onlinetaskmanager.models.SelectedMembers

class CardListAdapter(private val context: Context, private var cardList: ArrayList<Card>):
        RecyclerView.Adapter<CardListAdapter.MyViewHolder>() {

    private var onItemClickListener: OnCardItemClickListener? = null

    class MyViewHolder(bindingCard: ItemCardBinding): RecyclerView.ViewHolder(bindingCard.root) {
        val viewLabel = bindingCard.viewLabelColor
        val textViewCardName = bindingCard.tvCardName
        val recyclerViewCardList = bindingCard.rvCardMembersList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(ItemCardBinding.inflate(LayoutInflater.from(parent.context),
            parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, @SuppressLint("RecyclerView") position: Int) {
        val cardModel = cardList[position]
        if (cardModel.labelColor!!.isNotEmpty()) {
            holder.viewLabel.visibility = View.VISIBLE
            holder.viewLabel.setBackgroundColor(Color.parseColor(cardModel.labelColor))
        }
        else {
                holder.viewLabel.visibility = View.GONE
        }
        holder.textViewCardName.text = cardModel.name

        if ((context as TaskListActivity).assignedMembersList.size > 0) {
            val selectedMembersList: ArrayList<SelectedMembers> = ArrayList()
            // Here we got the detail list of members and add it to the selected members list as required
            for (i in context.assignedMembersList.indices) {
                for (j in cardModel.assignedTo!!) {
                    if (context.assignedMembersList[i].id == j) {
                        val selectedMember = SelectedMembers(context.assignedMembersList[i].id,
                            context.assignedMembersList[i].image)
                        selectedMembersList.add(selectedMember)
                    }
                }
            }

            if (selectedMembersList.size > 0) {
                if (selectedMembersList.size == 1 && selectedMembersList[0].id == cardModel.createdBy) {
                    holder.recyclerViewCardList.visibility = View.GONE
                }
                else {
                    holder.recyclerViewCardList.visibility = View.VISIBLE
                    holder.recyclerViewCardList.layoutManager = GridLayoutManager(context, 4)
                    val adapter = CardMembersListAdapter(context, selectedMembersList, false)
                    holder.recyclerViewCardList.adapter = adapter
                    adapter.setOnClickListener(object: CardMembersListAdapter.OnItemClickListener {
                        override fun onClick() {
                            if (onItemClickListener != null) {
                                onItemClickListener!!.onClick(position)
                            }
                        }
                    })
                }
            }
            else {
                holder.recyclerViewCardList.visibility = View.GONE
                }
        }

        holder.itemView.setOnClickListener {
            if (onItemClickListener != null) {
            onItemClickListener!!.onClick(position)
            }
        }
    }

    override fun getItemCount(): Int {
        return cardList.size
    }

    fun setOnItemClickListener(onClickListener: OnCardItemClickListener) {
        this.onItemClickListener = onClickListener
    }

    interface OnCardItemClickListener {
        fun onClick(cardPosition: Int)
    }

}