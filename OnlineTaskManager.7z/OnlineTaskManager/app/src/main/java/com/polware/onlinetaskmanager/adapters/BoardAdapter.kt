package com.polware.onlinetaskmanager.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.polware.onlinetaskmanager.R
import com.polware.onlinetaskmanager.databinding.ItemBoardBinding
import com.polware.onlinetaskmanager.models.Board

open class BoardAdapter(private val context: Context,
                        private var boardList: ArrayList<Board>): RecyclerView.Adapter<BoardAdapter.ViewHolder>() {

    private var onItemClickListener: OnItemClickListener? = null

    class ViewHolder(bindingAdapter: ItemBoardBinding):
        RecyclerView.ViewHolder(bindingAdapter.root) {
        val boardImage = bindingAdapter.ivBoardImage
        val boardName = bindingAdapter.tvBoardName
        val createdBy = bindingAdapter.tvCreatedBy
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(ItemBoardBinding.inflate(LayoutInflater
            .from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = boardList[position]
        Glide.with(context).load(model.image).centerCrop()
                .placeholder(R.drawable.ic_board_place_holder).into(holder.boardImage)
        holder.boardName.text = model.name
        holder.createdBy.text = buildString {
            append("Created by: ")
            append(model.createdBy)
            }

        holder.itemView.setOnClickListener {
            if (onItemClickListener != null){
                onItemClickListener!!.onClick(position, model)
            }
        }
    }

    override fun getItemCount(): Int {
        return boardList.size
    }

    interface OnItemClickListener {
        fun onClick(position: Int, model: Board)
    }

    fun setOnItemClickListener(onItemClickListener: OnItemClickListener) {
        this.onItemClickListener = onItemClickListener
    }

}