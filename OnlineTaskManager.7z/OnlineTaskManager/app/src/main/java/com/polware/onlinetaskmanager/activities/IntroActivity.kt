package com.polware.onlinetaskmanager.activities

import android.content.Intent
import android.os.Bundle
import com.polware.onlinetaskmanager.databinding.ActivityIntroBinding

class IntroActivity : BaseActivity() {
    private lateinit var bindingIntro: ActivityIntroBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingIntro = ActivityIntroBinding.inflate(layoutInflater)
        setContentView(bindingIntro.root)

        bindingIntro.buttonSignIn.setOnClickListener {
            startActivity(Intent(this, SignInActivity::class.java))
        }

        bindingIntro.buttonSignUp.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }

    }
}