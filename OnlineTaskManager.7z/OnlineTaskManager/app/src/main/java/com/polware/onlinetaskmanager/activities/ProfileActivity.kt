package com.polware.onlinetaskmanager.activities

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.polware.onlinetaskmanager.R
import com.polware.onlinetaskmanager.databinding.ActivityProfileBinding
import com.polware.onlinetaskmanager.firebase.FirestoreDB
import com.polware.onlinetaskmanager.models.User
import com.polware.onlinetaskmanager.utils.Constants.IMAGE
import com.polware.onlinetaskmanager.utils.Constants.NAME
import com.polware.onlinetaskmanager.utils.Constants.PHONE
import com.polware.onlinetaskmanager.utils.Constants.READ_STORAGE_PERMISSION_CODE
import com.polware.onlinetaskmanager.utils.Constants.getImageExtension
import java.io.IOException

class ProfileActivity : BaseActivity() {
    private lateinit var bindingProfile: ActivityProfileBinding
    private var activityResultLauncherImageSelected: ActivityResultLauncher<Intent>? = null
    private lateinit var userDetails: User
    private var selectedImageUri: Uri? = null
    private var profileImageUrl: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingProfile = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(bindingProfile.root)
        setupActionBar()
        FirestoreDB().loadUserData(this)
        registerActivityForImageSelected()

        bindingProfile.ivProfileUserImage.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
                showSelectImage()
            }
            else {
                ActivityCompat.requestPermissions(this,
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), READ_STORAGE_PERMISSION_CODE)
            }
        }

        bindingProfile.btnUpdateProfile.setOnClickListener {
            if (selectedImageUri != null) {
                uploadUserImage()
            }
            else {
                showProgressDialog(resources.getString(R.string.please_wait))
                updateUserProfile()
            }
        }

    }

    private fun setupActionBar() {
        setSupportActionBar(bindingProfile.toolbarProfileActivity)
        val actionBar = supportActionBar
        if (actionBar != null){
            actionBar.setDisplayHomeAsUpEnabled(true)
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back_arrow)
            actionBar.title = resources.getString(R.string.profile_tile)
        }
        bindingProfile.toolbarProfileActivity.setNavigationOnClickListener {
            onBackPressed()
        }
    }

    fun setUserDataOnUI(user: User) {
        userDetails = user
        Glide.with(this).load(user.image).centerCrop()
            .placeholder(R.drawable.ic_user_place_holder).into(bindingProfile.ivProfileUserImage)
        bindingProfile.etName.setText(user.name)
        bindingProfile.etEmail.setText(user.email)
        if (user.phone != 0L){
            bindingProfile.etMobile.setText(user.phone.toString())
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>,
                                            grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == READ_STORAGE_PERMISSION_CODE){
            if (grantResults.isNotEmpty() && grantResults[0]
                == PackageManager.PERMISSION_GRANTED){
                showSelectImage()
            }
        }
        else {
            Toast.makeText(this,
                "You have denied permission to external storage", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSelectImage(){
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        activityResultLauncherImageSelected?.launch(galleryIntent)
    }

    private fun registerActivityForImageSelected() {
        activityResultLauncherImageSelected = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()) { result ->
            val resultCode = result.resultCode
            val data = result.data
            if (resultCode == RESULT_OK && data != null) {
                try {
                    selectedImageUri = data.data
                    Glide.with(this).load(selectedImageUri).centerCrop()
                        .placeholder(R.drawable.ic_user_place_holder).into(bindingProfile.ivProfileUserImage)
                } catch (e: IOException) {
                    e.printStackTrace()
                    Toast.makeText(this@ProfileActivity, "Error loading image",
                        Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun uploadUserImage(){
        showProgressDialog(resources.getString(R.string.please_wait))
        if (selectedImageUri != null){
            val storageReference: StorageReference = FirebaseStorage
                .getInstance().reference.child("USER_IMAGE" + System.currentTimeMillis() +
                        "." + getImageExtension(this, selectedImageUri))
            storageReference.putFile(selectedImageUri!!).addOnSuccessListener {
                taskSnapshot ->
                Log.i("Firebase Image URL:",
                    taskSnapshot.metadata!!.reference!!.downloadUrl.toString())
                taskSnapshot.metadata!!.reference!!.downloadUrl.addOnSuccessListener {
                    uri ->
                    Log.i("Link Image:", uri.toString())
                    profileImageUrl = uri.toString()
                    updateUserProfile()
                }
            }.addOnFailureListener {
                exception ->
                Toast.makeText(this, exception.message, Toast.LENGTH_SHORT).show()
                hideProgressDialog()
            }
        }
    }
    /*
    // Return the extension for the given file (URI)
    private fun getImageExtension(uri: Uri?): String? {
        return MimeTypeMap.getSingleton()
            .getExtensionFromMimeType(contentResolver.getType(uri!!))
    }
    */
    private fun updateUserProfile() {
        val userHashMap = HashMap<String, Any>()
        val phone = bindingProfile.etMobile.text.toString()
        if (profileImageUrl.isNotEmpty() && profileImageUrl != userDetails.image)
            userHashMap[IMAGE] = profileImageUrl
        if (bindingProfile.etName.text.toString() != userDetails.name)
            userHashMap[NAME] = bindingProfile.etName.text.toString()
        if (phone.isEmpty())
            userHashMap[PHONE] = 0
        else if (phone != userDetails.phone.toString())
            userHashMap[PHONE] = bindingProfile.etMobile.text.toString().toLong()
        FirestoreDB().updateUserProfileToDB(this, userHashMap)
    }

    fun profileUpdateSuccess() {
        hideProgressDialog()
        setResult(Activity.RESULT_OK)
        finish()
    }

}