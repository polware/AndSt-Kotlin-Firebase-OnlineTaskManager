package com.polware.onlinetaskmanager.firebase

import android.app.Activity
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.polware.onlinetaskmanager.activities.*
import com.polware.onlinetaskmanager.models.Board
import com.polware.onlinetaskmanager.models.User
import com.polware.onlinetaskmanager.utils.Constants.ASSIGNED_TO
import com.polware.onlinetaskmanager.utils.Constants.BOARDS
import com.polware.onlinetaskmanager.utils.Constants.EMAIL
import com.polware.onlinetaskmanager.utils.Constants.TASK_LIST
import com.polware.onlinetaskmanager.utils.Constants.USERS
import com.polware.onlinetaskmanager.utils.Constants.USER_ID

class FirestoreDB {
    private val fireStore = FirebaseFirestore.getInstance()

    fun registerUserToDB(activity: SignUpActivity, userInfo: User){
        fireStore.collection(USERS).document(getCurrentUserID())
            .set(userInfo, SetOptions.merge()).addOnSuccessListener {
                activity.registeredUserConfirmation()
            }
            .addOnFailureListener { e ->
                Log.e(activity.javaClass.simpleName, "Error writing document", e)
            }
    }

    fun loadUserData(activity: Activity, readBoardList: Boolean = false){
        fireStore.collection(USERS).document(getCurrentUserID())
            .get().addOnSuccessListener {
                document ->
                // Obtiene datos del usuarios almacenados en la colección "users" de FireStore
                val userLoggedIn = document.toObject(User::class.java)
                when(activity) {
                    is SignInActivity -> {
                        activity.signInSuccess(userLoggedIn!!)
                    }
                    is MainActivity -> {
                        activity.updateNavigationUserInfo(userLoggedIn!!, readBoardList)
                    }
                    is ProfileActivity -> {
                        activity.setUserDataOnUI(userLoggedIn!!)
                    }
                }
            }
            .addOnFailureListener { error ->
                Log.e("FireStore SignInUser", "Error at sign in", error)
                when(activity) {
                    is SignInActivity -> {
                        activity.hideProgressDialog()
                    }
                    is MainActivity -> {
                        activity.hideProgressDialog()
                    }
                }
            }
    }

    fun updateUserProfileToDB(activity: Activity, userHashMap: HashMap<String, Any>){
        fireStore.collection(USERS).document(getCurrentUserID())
            .update(userHashMap).addOnSuccessListener {
                Log.i(activity.javaClass.simpleName, "Profile Updated")
                Toast.makeText(activity, "Profile updated successfully", Toast.LENGTH_SHORT).show()
                when (activity) {
                    is MainActivity -> {
                        activity.tokenUpdatedSuccess()
                    }
                    is ProfileActivity -> {
                        activity.profileUpdateSuccess()
                    }
                }
        }.addOnFailureListener {
            error ->
                when (activity) {
                    is MainActivity -> {
                        activity.hideProgressDialog()
                    }
                    is ProfileActivity -> {
                        activity.hideProgressDialog()
                    }
                }
                Log.e(activity.javaClass.simpleName, "Error updating profile", error)
                Toast.makeText(activity, "Error updating profile", Toast.LENGTH_SHORT).show()
            }
    }

    fun getCurrentUserID(): String {
        val currentUser = FirebaseAuth.getInstance().currentUser
        var currentUserID = ""
        if (currentUser != null) {
            currentUserID = currentUser.uid
        }
        return currentUserID
    }

    fun createBoard(activity: NewBoardActivity, board: Board) {
        fireStore.collection(BOARDS).document()
            .set(board, SetOptions.merge()).addOnSuccessListener {
            Log.i(activity.javaClass.simpleName, "Board created on FireStore")
            Toast.makeText(activity, "Board created successfully", Toast.LENGTH_SHORT).show()
            activity.boardCreatedSuccessfully()
        }.addOnFailureListener {
            exception ->
                activity.hideProgressDialog()
                Log.e(activity.javaClass.simpleName, "Error creating Board", exception)
            }
    }

    fun getBoardsList(activity: MainActivity) {
        fireStore.collection(BOARDS).whereArrayContains(ASSIGNED_TO, getCurrentUserID())
            .get().addOnSuccessListener {
                document ->
                Log.i(activity.javaClass.simpleName, document.documents.toString())
                val boardList: ArrayList<Board> = ArrayList()
                for (i in document.documents){
                    val board = i.toObject(Board::class.java)!!
                    board.documentId = i.id
                    boardList.add(board)
                }
                activity.loadBoardsList(boardList)
        }.addOnFailureListener {
            error ->
                activity.hideProgressDialog()
                Log.e(activity.javaClass.simpleName, "Error getting Board list", error)
            }
    }

    fun getBoardDetails(activity: TaskListActivity, documentId: String){
        fireStore.collection(BOARDS).document(documentId)
            .get().addOnSuccessListener {
                    document ->
                Log.i(activity.javaClass.simpleName, document.toString())
                val board = document.toObject(Board::class.java)
                board!!.documentId = document.id
                activity.boardDetails(board)
            }.addOnFailureListener {
                    error ->
                activity.hideProgressDialog()
                Log.e(activity.javaClass.simpleName, "Error getting Board details", error)
            }
    }

    fun addUpdateTaskList(activity: Activity, board: Board) {
        val taskListHashMap = HashMap<String, Any>()
        taskListHashMap[TASK_LIST] = board.taskList!!
        fireStore.collection(BOARDS).document(board.documentId!!)
            .update(taskListHashMap).addOnSuccessListener {
                Log.i(activity.javaClass.simpleName, "TaskList updated")
                if (activity is TaskListActivity)
                    activity.addUpdateTaskListSuccess()
                else if (activity is CardDetailsActivity)
                    activity.addUpdateCardListSuccess()
        }.addOnFailureListener {
            exception ->
                if (activity is TaskListActivity)
                    activity.hideProgressDialog()
                else if (activity is CardDetailsActivity)
                    activity.hideProgressDialog()
                Log.e(activity.javaClass.simpleName, "ERROR updating tasklist", exception)
            }
    }

    fun getAssignedMembersDetails(activity: Activity, assignedTo: ArrayList<String>) {
        fireStore.collection(USERS).whereIn(USER_ID, assignedTo).get().addOnSuccessListener {
            document ->
            Log.i(activity.javaClass.simpleName, document.documents.toString())
            val usersList: ArrayList<User> = ArrayList()
            for (i in document.documents) {
                val user = i.toObject(User::class.java)
                usersList.add(user!!)
            }
            if (activity is MembersActivity)
                activity.setupMembersList(usersList)
            else if (activity is TaskListActivity)
                activity.boardMembersList(usersList)
        }.addOnFailureListener { exception ->
            if (activity is MembersActivity)
                activity.hideProgressDialog()
            else if (activity is TaskListActivity)
                activity.hideProgressDialog()
            Log.e(activity.javaClass.simpleName, "ERROR getting users list", exception)
        }

    }

    fun getMemberDetails(activity: MembersActivity, email: String) {
        fireStore.collection(USERS).whereEqualTo(EMAIL, email).get().addOnSuccessListener {
            document ->
            if (document.documents.size > 0) {
                val user = document.documents[0].toObject(User::class.java)!!
                activity.memberDetails(user)
            }
            else {
                activity.hideProgressDialog()
                activity.showErrorMessage("No such member found")
            }
        }.addOnFailureListener {
            exception ->
            activity.hideProgressDialog()
            Log.e(activity.javaClass.simpleName, "ERROR getting user details", exception)
        }
    }

    fun assignMemberToBoard(activity: MembersActivity, board: Board, user: User) {
        val assignedToHashMap = HashMap<String, Any>()
        assignedToHashMap[ASSIGNED_TO] = board.assignedTo!!
        fireStore.collection(BOARDS).document(board.documentId!!)
            .update(assignedToHashMap).addOnCompleteListener {
                activity.memberAssignedSuccess(user)
            }
            .addOnFailureListener {
                exception ->
                activity.hideProgressDialog()
                Log.e(activity.javaClass.simpleName, "ERROR updating assigned to user", exception)
            }
    }

}