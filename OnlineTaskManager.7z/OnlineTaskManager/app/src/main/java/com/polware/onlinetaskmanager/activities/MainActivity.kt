package com.polware.onlinetaskmanager.activities

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging
import com.polware.onlinetaskmanager.*
import com.polware.onlinetaskmanager.adapters.BoardAdapter
import com.polware.onlinetaskmanager.databinding.ActivityMainBinding
import com.polware.onlinetaskmanager.databinding.NavHeaderMainBinding
import com.polware.onlinetaskmanager.firebase.FirestoreDB
import com.polware.onlinetaskmanager.models.Board
import com.polware.onlinetaskmanager.models.User
import com.polware.onlinetaskmanager.utils.Constants.APP_PREFERENCES
import com.polware.onlinetaskmanager.utils.Constants.DOCUMENT_ID
import com.polware.onlinetaskmanager.utils.Constants.FCM_TOKEN
import com.polware.onlinetaskmanager.utils.Constants.FCM_TOKEN_UPDATED
import com.polware.onlinetaskmanager.utils.Constants.NAME

class MainActivity: BaseActivity(), NavigationView.OnNavigationItemSelectedListener {
    private lateinit var binding: ActivityMainBinding
    private lateinit var includedViewToolbar: Toolbar
    private lateinit var includedFAB: FloatingActionButton
    private lateinit var navViewHeaderBinding: NavHeaderMainBinding
    private lateinit var recyclerViewMain: RecyclerView
    private lateinit var textViewNoBoards: TextView
    private var activityResultLauncherUserProfile: ActivityResultLauncher<Intent>? = null
    private var activityResultLauncherNewBoard: ActivityResultLauncher<Intent>? = null
    private lateinit var userName: String
    private lateinit var mySharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupActionBar()
        mySharedPreferences = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE)
        val tokenUpdated = mySharedPreferences.getBoolean(FCM_TOKEN_UPDATED, false)
        if (tokenUpdated) {
            showProgressDialog(resources.getString(R.string.please_wait))
            FirestoreDB().loadUserData(this, true)
        }
        else {
            FirebaseMessaging.getInstance().token.addOnSuccessListener {
                token ->
                updateFCMToken(token)
            }
        }

        includedFAB = binding.appToolbar.fabCreateBoard
        recyclerViewMain = binding.appToolbar.mainContent.rvBoardsList
        textViewNoBoards = binding.appToolbar.mainContent.tvNoBoardsAvailable

        // Binding del Header de NavigationView
        val viewHeader = binding.navigationView.getHeaderView(0)
        navViewHeaderBinding = NavHeaderMainBinding.bind(viewHeader)
        registerActivityForUserProfile()
        registerActivityForNewBoard()

        binding.navigationView.setNavigationItemSelectedListener(this)
        FirestoreDB().loadUserData(this, true)

        includedFAB.setOnClickListener {
            val intentNewBoard = Intent(this, NewBoardActivity::class.java)
            intentNewBoard.putExtra(NAME, userName)
            activityResultLauncherNewBoard?.launch(intentNewBoard)
        }
    }

    private fun setupActionBar() {
        includedViewToolbar = binding.appToolbar.toolbarMainActivity
        setSupportActionBar(includedViewToolbar)
        includedViewToolbar.setNavigationIcon(R.drawable.ic_navigation_menu)
        includedViewToolbar.setNavigationOnClickListener {
            toggleDrawer()
        }
    }

    // Se programa el vento de abrir o cerrar el DrawerLayout
    private fun toggleDrawer() {
        if(binding.drawerLayout.isDrawerOpen(GravityCompat.START)){
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        }
        else {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        }
    }

    // Sobreescribimos el evento de presionar atrás
    override fun onBackPressed() {
        //super.onBackPressed()
        if(binding.drawerLayout.isDrawerOpen(GravityCompat.START)){
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        }
        else {
            doubleBackToExit()
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.nav_my_profile -> {
                val intentProfile = Intent(this, ProfileActivity::class.java)
                activityResultLauncherUserProfile?.launch(intentProfile)
            }
            R.id.nav_sign_out -> {
                FirebaseAuth.getInstance().signOut()
                // Por seguridad limpiamos el token de Shared Preferences
                mySharedPreferences.edit().clear().apply()
                val intent = Intent(this, IntroActivity::class.java)
                // Clear Top: cierra antiguas activities y deja primero en la pila la nueva activity
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                finish()
            }
        }
        binding.drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun registerActivityForUserProfile() {
        activityResultLauncherUserProfile = registerForActivityResult(ActivityResultContracts
            .StartActivityForResult()) {
                result ->
            val resultCode = result.resultCode
            if (resultCode == RESULT_OK) {
                try {
                    FirestoreDB().loadUserData(this)
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("ErrorActResult: ", e.message.toString())
                }
            }
            else Log.i("ProfileActivity: ", "Profile don't updated")
        }
    }

    private fun registerActivityForNewBoard() {
        activityResultLauncherNewBoard = registerForActivityResult(ActivityResultContracts
            .StartActivityForResult()) {
                result ->
            val resultCode = result.resultCode
            if (resultCode == RESULT_OK) {
                try {
                    FirestoreDB().getBoardsList(this)
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("ErrorLoadingBoardList: ", e.message.toString())
                }
            }
            else Log.i("BoardActivity: ", "Board don't created")
        }
    }

    fun updateNavigationUserInfo(user: User, readBoardList: Boolean) {
        hideProgressDialog()
        userName = user.name!!
        Glide.with(this).load(user.image).centerCrop()
            .placeholder(R.drawable.ic_user_place_holder).into(navViewHeaderBinding.ivUserImage)
        navViewHeaderBinding.tvUsername.text = user.name
        if (readBoardList){
            showProgressDialog(resources.getString(R.string.please_wait))
            FirestoreDB().getBoardsList(this)
        }
    }

    fun loadBoardsList(boardList: ArrayList<Board>) {
        hideProgressDialog()
        if (boardList.size > 0){
            recyclerViewMain.visibility = View.VISIBLE
            textViewNoBoards.visibility = View.GONE
            recyclerViewMain.layoutManager = LinearLayoutManager(this)
            recyclerViewMain.setHasFixedSize(true)
            val adapter = BoardAdapter(this, boardList)
            recyclerViewMain.adapter = adapter
            // Instanciamos el Listener creado en el adaptador
            adapter.setOnItemClickListener(object : BoardAdapter.OnItemClickListener {
                override fun onClick(position: Int, model: Board) {
                    val intentTaskList = Intent(this@MainActivity, TaskListActivity::class.java)
                    intentTaskList.putExtra(DOCUMENT_ID, model.documentId)
                    startActivity(intentTaskList)
                }
            })
        }
        else {
            recyclerViewMain.visibility = View.GONE
            textViewNoBoards.visibility = View.VISIBLE
        }
    }

    fun tokenUpdatedSuccess() {
        hideProgressDialog()
        val editor = mySharedPreferences.edit()
        editor.putBoolean(FCM_TOKEN_UPDATED, true)
        editor.apply()
        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().loadUserData(this, true)
    }

    private fun updateFCMToken(token: String) {
        val userHashMap = HashMap<String, Any>()
        userHashMap[FCM_TOKEN] = token
        showProgressDialog(resources.getString(R.string.please_wait))
        FirestoreDB().updateUserProfileToDB(this, userHashMap)
    }

}